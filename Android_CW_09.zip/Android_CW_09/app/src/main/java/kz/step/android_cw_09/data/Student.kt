package kz.step.android_cw_09.data

class Student {
    var name: String = ""
    var surname: String = ""
}