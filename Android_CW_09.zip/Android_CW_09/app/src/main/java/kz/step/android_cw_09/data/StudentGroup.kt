package kz.step.android_cw_09.data

class StudentGroup{
    var student: Student? = null
    var group: Group? = null
}