package kz.step.android_cw_09.data

class Group {

    var title: String? = null

}