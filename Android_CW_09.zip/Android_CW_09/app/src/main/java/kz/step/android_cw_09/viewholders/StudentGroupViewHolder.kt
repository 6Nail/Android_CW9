package kz.step.android_cw_09.viewholders

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kz.step.android_cw_09.R
import kz.step.android_cw_09.data.StudentGroup

class StudentGroupViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {

    var textviewName: TextView? = null
    var textviewSurname: TextView? = null
    var textViewGroup: TextView? = null

    init {
        textviewName = itemView.findViewById(R.id.textview_viewholder_name)
        textviewSurname = itemView.findViewById(R.id.textview_viewholder_surname)
        textViewGroup = itemView.findViewById(R.id.textview_viewholder_group)
    }

    fun bind(studentGroup: StudentGroup){
        textviewName?.text = studentGroup.student?.name
        textviewSurname?.text = studentGroup.student?.surname
        textViewGroup?.text = studentGroup.group?.title
    }

}