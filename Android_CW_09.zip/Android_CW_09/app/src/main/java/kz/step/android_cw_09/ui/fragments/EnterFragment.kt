package kz.step.android_cw_09.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kz.step.android_cw_09.R
import kz.step.android_cw_09.adapters.StudentGroupAdapter
import kz.step.android_cw_09.adapters.StudentsAdapter
import kz.step.android_cw_09.data.Group
import kz.step.android_cw_09.data.Student
import kz.step.android_cw_09.data.StudentGroup

class EnterFragment : Fragment() {

    lateinit var rootView: View

    var students: RecyclerView? = null
    var studentGroupAdapter: StudentGroupAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        rootView =
                LayoutInflater.from(requireContext())
                        .inflate(
                                R.layout.fragment_enter,
                                container,
                                false
                        )
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeViews()
        initializeAdapter()
        initializeLinearLayoutManager()
    }

    fun initializeViews() {
        students = rootView.findViewById(R.id.recyclerview_fragment_enter_students)
    }

    fun initializeAdapter() {

        studentGroupAdapter = StudentGroupAdapter(mutableListOf<StudentGroup>(
                StudentGroup().apply {
                    student = Student().apply {
                        name = "John"
                        surname = "Wick"
                    }
                    group = Group().apply {
                        title = "AAA-001"
                    }
                },
                StudentGroup().apply {
                    student = Student().apply {
                        name = "Peter"
                        surname = "Wick"
                    }
                    group = Group().apply {
                        title = "AAA-002"
                    }
                },
                StudentGroup().apply {
                    student = Student().apply {
                        name = "John"
                        surname = "Wick"
                    }
                    group = Group().apply {
                        title = "ABB-021"
                    }
                },
                StudentGroup().apply {
                    student = Student().apply {
                        name = "John"
                        surname = "Wick"
                    }
                    group = Group().apply {
                        title = "CAD-011"
                    }
                } ,
                StudentGroup().apply {
                    student = Student().apply {
                        name = "Ellen"
                        surname = "Page"
                    }
                    group = Group().apply {
                        title = "AAA-001"
                    }
                },
                StudentGroup().apply {
                    student = Student().apply {
                        name = "John"
                        surname = "Wick"
                    }
                    group = Group().apply {
                        title = "AAA-001"
                    }
                })
        )



        students?.adapter = studentGroupAdapter
    }

    fun initializeLinearLayoutManager(){
        students?.layoutManager = LinearLayoutManager(requireContext())
    }
}